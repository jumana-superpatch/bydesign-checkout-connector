import {
  reactExtension,
  useEmail,
  Banner,
  Text,
  useAttributes,
  Button,
  useApplyMetafieldsChange,
  useMetafields,
  // useApplyAttributeChange, // keep around if you ever need attributes again
} from '@shopify/ui-extensions-react/checkout';
import { useEffect, useState } from 'react';

export default reactExtension('purchase.checkout.block.render', () => (
  <ExtensionApp />
));

function ExtensionApp() {
  const email = useEmail();
  // const applyAttributeChange = useApplyAttributeChange(); // attributes 
  const applyMetafieldChange = useApplyMetafieldsChange(); // using metafields
  const attributes = useAttributes();
  const metafields = useMetafields({ namespace: 'bdt' });


  const [status, setStatus] = useState({
    loading: false,
    customerDID: null,
    isRep: false,
    repDID: null,
    repEmail: null,
    error: null,
  });

  useEffect(() => {
    if (!email) return;
    let cancelled = false;

    async function runLookup() {
      setStatus((s) => ({ ...s, loading: true }));

      try {
        console.log('[ByDesign Check] Email from checkout:', email);

        const resp = await fetch(
          `https://bydesign-checkout-worker.cloudflare-superpatch.workers.dev/lookup-checkout?email=${encodeURIComponent(
            email
          )}`
        );

        if (!resp.ok) {
          throw new Error(`Worker returned ${resp.status}`);
        }

        const json = await resp.json();
        console.log('[ByDesign Check] Worker response:', json);

        if (!cancelled) {
          const customerDID = json?.customer?.did || null;
          const isRep = !!json?.rep?.isRep;
          const repDID = json?.rep?.repDID || null;
          const repEmail = json?.rep?.repEmail || null;

          // Save to cart metafields
          await Promise.all([
            safeUpdateMetafield({
              namespace: 'bdt',
              key: 'customer_did',
              value: customerDID,
            }),
            safeUpdateMetafield({
              namespace: 'bdt',
              key: 'rep_did',
              value: repDID,
            }),
            safeUpdateMetafield({
              namespace: 'bdt',
              key: 'rep_email',
              value: repEmail,
            }),
          ]);

          /* Cart attributes version 
          await Promise.all([
            applyAttributeChange({
              type: 'updateAttribute',
              key: '__bdt_customer_did',
              value: customerDID || '',
            }),
            applyAttributeChange({
              type: 'updateAttribute',
              key: '__bdt_rep_did',
              value: repDID || '',
            }),
            applyAttributeChange({
              type: 'updateAttribute',
              key: '__bdt_rep_email',
              value: repEmail || '',
            }),
          ]);
          */

          setStatus({
            loading: false,
            customerDID,
            isRep,
            repDID,
            repEmail,
            error: null,
          });
          console.log("Cart metafields:", metafields);
        }
      } catch (err) {
        console.error('[ByDesign Check] Error:', err);
        if (!cancelled) {
          setStatus({
            loading: false,
            customerDID: null,
            isRep: false,
            repDID: null,
            repEmail: null,
            error: err.message,
          });
        }
      }
    }

    async function safeUpdateMetafield({ namespace, key, value }) {
      if (value) {
        return applyMetafieldChange({
          type: 'updateMetafield',
          namespace,
          key,
          valueType: 'string',
          value,
        });
      } else {
        // If you want to remove instead of skip:
        return applyMetafieldChange({
          type: 'removeMetafield',
          namespace,
          key,
        });
      }
    }

    runLookup();
    return () => {
      cancelled = true;
    };
  }, [email]);

  if (!email) return null;
  if (!email) return <Text>Waiting for email…</Text>;
  if (status.loading) return <Text>Checking ByDesign…</Text>;
  if (status.error) return <Text>Error: {status.error}</Text>;

  return (
    <>
      {status.isRep && (
        <Banner title="ByDesign Rep Found" status="info">
          <Text>We found your Rep in ByDesign.</Text>
          <Button to="https://shop.superpatch.com/#/login">
            Shop with Rep
          </Button>
        </Banner>
      )}

      {/* Debug panel for cart attributes */}
      {/* {attributes && (
        <Banner title="Cart attributes (live)" status="success">
          <Text>{JSON.stringify(attributes, null, 2)}</Text>
        </Banner>
      )} */}
      {metafields && (
        <Banner title="Cart metafields (live)" status="success">
          <Text>{JSON.stringify(metafields, null, 2)}</Text>
        </Banner>
      )}
    </>
  );
}
